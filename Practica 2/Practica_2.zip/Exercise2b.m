clear all
close all
grad=Sobel('rice.tif',25);